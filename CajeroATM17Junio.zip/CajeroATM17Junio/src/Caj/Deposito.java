package Caj;

public class Deposito extends Cajero{
    
	//M�todo heredado de la clase Cajero por eso lleva @Override
	@Override
	public void Transacciones() {
	System.out.println("Cuanto deseas depositar: ");
	Deposito();
	transacciones = getSaldo();
	setSaldo(transacciones +  deposito);
	System.out.println("Depositaste: " + deposito);
	System.out.println("Tu saldoa actual es de: " + getSaldo());
	}

	
}
