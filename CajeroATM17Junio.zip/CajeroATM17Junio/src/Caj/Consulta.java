package Caj;

public class Consulta extends Cajero{
	
	//M�todo heredado de la clase Cajero por eso lleva @Override
	@Override 
	public void Transacciones() {
		System.out.println("Tu saldo actula es: " + getSaldo());
	}
	

}
