package Caj;

import java.util.Scanner;

public abstract class Cajero {

	Scanner sc = new Scanner(System.in);
	
	int transacciones;
	int retiro;
	int deposito;
	private static int saldo;
	
	public void operaciones() {
		int bandera = 0;
		int seleccion = 0;
		do {
		do {
			System.out.println("Seleccione una opci�n");
			System.out.println("   1.Consulta de saldo");
			System.out.println("   2.Retiro de efectivo");
			System.out.println("   3.Deposito de efectivo");
			System.out.println("   4.Salir");
			seleccion = sc.nextInt();
			 
			if (seleccion>=1 && seleccion <= 4) {
				bandera = 1;
			}else {
				System.out.println("Opcion no disponible ");
			}
		}while(bandera == 0 );
		      
		
		if (seleccion == 1) {
			 Cajero mensaje = new Consulta();
			 mensaje.Transacciones();
			 
		}else if(seleccion == 2){
			 Cajero mensaje = new Retiro();
			 mensaje.Transacciones();
			 
		}else if(seleccion == 3) {
			 Cajero mensaje = new Deposito();
			 mensaje.Transacciones();
			 
		} else if(seleccion == 4) {
			System.out.println("Gracias");
			bandera = 2;
		}
		
	}while(bandera != 2);
	
   }
	
   //M�todo para solicitar cantidad de retiro
	public void Retiro() {
	retiro = sc.nextInt();	
	}
	
	//M�todo para solictar deposito
	public void Deposito() {
		deposito = sc.nextInt();
	}
	
	//M�todo abstracto
	public abstract void Transacciones();
	
	//M�todo set establecer y get obtener
	 public int getSaldo() {
		 return saldo;
	 }
	 
	 public void setSaldo(int saldo) {
		 this.saldo = saldo;
	 }
	
}
