package Caj;

public class Principal {
	
	public static void main(String[] args) {
		
		Cajero mensaje = new Consulta();
		mensaje.setSaldo(12550);
		mensaje.operaciones();
		
	}
}
